const mongoose=require("mongoose")

const movies= new mongoose.Schema({
    title:{
        type:String
    },
    releaseYear:{type:Number},
    gener:{
        type:mongoose.Schema.Types.ObjectId,
        ref:gener
    }
})

exports.module = mongoose.model("movie",movies)