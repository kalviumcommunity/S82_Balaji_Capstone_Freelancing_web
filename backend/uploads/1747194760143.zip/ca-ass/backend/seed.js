const mongoose=require('mongoose')
const Movies=require("./movie")
const Gener=require("./genre")

const seedData=async()=>{
    const movies=[
        {title:"Inception",releaseYear:2010,gener:"Sci-Fi"},
        {title:"The Dark Knight",releaseYear:2008,gener:"Action"},
    ]
    await mongoose.insertMany(movies)
    console.log("movies are added")

    const gener=[
        {name:"Sci-Fi"}
    ]
    await mongoose.insertMany(gener)
    console.log("gener are added")
}

seedData();