const mongoose=require("mongoose")

const geners= new mongoose.Schema({
    name:{
        type:String
    }
})

exports.module = mongoose.model("gener",geners)