
required("dotenv").config();
const mongoose=require("mongoose")

const connectDB=(async()=>{
    try{
     await mongoose.connection(process.env.MONGO)
     console.log("DB connected")
    }
    catch(err){
        console.log("error in connecting",err.message)
    }
});

export default connectDB();